package w12;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ex_1 extends JFrame {
    private String[] imageFiles = {
        "images/image0.jpg",
        "images/image1.jpg",
        "images/image2.jpg",
        "images/image3.jpg"
    };

    private int currentIndex = 0;     
    private JLabel imageLabel;        

    public ex_1() {
        setTitle("Open Challenge 11");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // CENTER 영역: 이미지 레이블 
        imageLabel = new JLabel();
        imageLabel.setHorizontalAlignment(JLabel.CENTER);
        imageLabel.setIcon(new ImageIcon(imageFiles[currentIndex]));
        add(imageLabel, BorderLayout.CENTER);

        // 좌/우 화살표 버튼 패널 
        JPanel southPanel = new JPanel();
        southPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));	
        
        JButton leftButton = new JButton(new ImageIcon("images/left.png"));   
        JButton rightButton = new JButton(new ImageIcon("images/right.png"));

        southPanel.add(leftButton);
        southPanel.add(rightButton);
        add(southPanel, BorderLayout.SOUTH);

        // 좌측 버튼 이벤트
        leftButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentIndex--;
                if (currentIndex < 0) {
                    currentIndex = imageFiles.length - 1;  
                }
                imageLabel.setIcon(new ImageIcon(imageFiles[currentIndex]));
            }
        });

        // 우측 버튼 이벤트
        rightButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentIndex++;
                if (currentIndex >= imageFiles.length) {
                    currentIndex = 0;  
                }
                imageLabel.setIcon(new ImageIcon(imageFiles[currentIndex]));
            }
        });

        setSize(500, 500);
        setVisible(true);
    }

    public static void main(String[] args) {
        new ex_1();
    }
}