package w12;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ex_2 extends JFrame {
    private String[] imageFiles = {
        "images/gawi.jpg",   
        "images/bawi.jpg",   
        "images/bo.jpg"      
    };
    private String[] names = {"가위", "바위", "보"};

    private JLabel meImageLabel;       
    private JLabel comImageLabel;      
    private JLabel resultLabel;        

    public ex_2() {
        setTitle("가위 바위 보 게임");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(2, 1));  

        // 위쪽 패널: 가위/바위/보 선택 버튼 3개 
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        topPanel.setBackground(Color.WHITE);

        for (int i = 0; i < 3; i++) {
            JButton btn = new JButton(new ImageIcon(imageFiles[i]));
            final int choice = i;  
            btn.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    playGame(choice);
                }
            });
            topPanel.add(btn);
        }
        add(topPanel);

        // 아래쪽 패널: 결과 표시 
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 30));
        bottomPanel.setBackground(Color.YELLOW);

        meImageLabel = new JLabel();
        JLabel meText = new JLabel("me");

        comImageLabel = new JLabel();
        JLabel comText = new JLabel("com");

        resultLabel = new JLabel("");
        resultLabel.setForeground(Color.RED);
        resultLabel.setFont(new Font("Dialog", Font.BOLD, 18));

        bottomPanel.add(meImageLabel);
        bottomPanel.add(meText);
        bottomPanel.add(comImageLabel);
        bottomPanel.add(comText);
        bottomPanel.add(resultLabel);
        add(bottomPanel);

        setSize(650, 500);
        setVisible(true);
    }

    private void playGame(int myChoice) {

        int comChoice = (int)(Math.random() * 3);
        
        meImageLabel.setIcon(new ImageIcon(imageFiles[myChoice]));
        comImageLabel.setIcon(new ImageIcon(imageFiles[comChoice]));
       
        String result;
        if (myChoice == comChoice) {
            result = "Same !!!";
        } else if (
            (myChoice == 0 && comChoice == 2) ||  
            (myChoice == 1 && comChoice == 0) ||  
            (myChoice == 2 && comChoice == 1)     
        ) {
            result = "You Win !!!";
        } else {
            result = "Com Win !!!";
        }
        resultLabel.setText(result);
    }

    public static void main(String[] args) {
        new ex_2();
    }
}